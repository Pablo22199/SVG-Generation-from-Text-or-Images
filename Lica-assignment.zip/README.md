# 🧩 Image → SVG (Super Simple)

**What this does (in plain words):**  
I take a small set of PNG icons and try two ways to turn them into SVGs:
- **Potrace (classic, no ML):** fast, but lots of messy paths.
- **StarVector (AI):** smarter, usually cleaner SVG with real shapes.

**Why SVG?** It stays sharp when zoomed and is easy to edit.

---

## How to run (Google Colab friendly)

1) Upload this ZIP to Colab. Then run:

```python
!unzip -o Lica-Research-Assignment-Simple.zip -d .
%pip install -r Lica-Research-Assignment-Simple/requirements.txt
!apt-get -y install potrace
```

2) Open `simple_notebook.ipynb` and run cells **top to bottom**.

Outputs go to `runs/B0_svg/` (Potrace) and `runs/B1_svg/` (StarVector).

---

## What you can say in the interview

- I compared a classic tracer vs a small AI model for vectorizing images.  
- AI (StarVector) produced cleaner SVGs with more `<rect>/<circle>` and fewer giant `<path>` blobs.  
- I used a tiny random sample to keep it fast and reproducible.  
- Next steps: add a metric CSV and try a tiny fine‑tune with a differentiable renderer (DiffVG).

---

## Repo layout

```
Lica-Research-Assignment-Simple/
├── README.md
├── simple_notebook.ipynb        # run this
├── requirements.txt
├── samples/
│   ├── gt_svg/                  # filled by notebook
│   └── gt_png/                  # filled by notebook
└── runs/
    ├── B0_svg/                  # Potrace outputs
    └── B1_svg/                  # StarVector outputs
```
